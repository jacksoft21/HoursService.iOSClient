//
//  EntryCell.swift
//  HoursService.iOSClient
//
//  Created by Ian Roberts on 2/20/15.
//  Copyright (c) 2015 Ian Roberts. All rights reserved.
//

import UIKit

class EntryCell: UITableViewCell {
    
    @IBOutlet weak var hours: UILabel!
    
    @IBOutlet weak var comments: UILabel!
    
    @IBOutlet weak var times: UILabel!
}
